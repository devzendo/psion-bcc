 
#include <plib.h>


GLDEF_C VOID main(VOID)
{
}

